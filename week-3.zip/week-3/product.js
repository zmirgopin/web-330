    /**
================================
Title: product.js
Author: Zahava Gopin 
Date: 18 January 2023
Description: JavaScript for restaurant.html
================================
*/
"use strict";
export class Product
{
    constructor (name , price)
    {
        this.name = name;
        this.price = price; 
    }
}
